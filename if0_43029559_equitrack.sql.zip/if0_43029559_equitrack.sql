-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql304.infinityfree.com
-- Generation Time: Nov 07, 2026 at 08:58 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43029559_equitrack`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `type` enum('equipment','facility') NOT NULL DEFAULT 'equipment',
  `category` varchar(60) NOT NULL,
  `qty` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `item_condition` enum('Good','Fair','Poor','Damaged') NOT NULL DEFAULT 'Good',
  `location` varchar(120) NOT NULL DEFAULT '',
  `manual_status` enum('','maintenance','unavailable') NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `name`, `type`, `category`, `qty`, `item_condition`, `location`, `manual_status`, `created_at`) VALUES
(1, 'Basketball ball', 'equipment', 'Sports', 1, 'Fair', 'School Gym', '', '2026-10-12 06:18:48'),
(2, 'School Gymnasium', 'facility', 'Facility', 1, 'Good', 'Main Campus', '', '2026-10-12 06:32:17'),
(3, 'Audio-Visual Room (AVR)', 'facility', 'Facility', 1, 'Good', 'Announciation bld, Ground Floor', '', '2026-10-12 06:32:17'),
(4, 'School Chapel', 'facility', 'Facility', 1, 'Good', 'Ground Floor', '', '2026-10-12 06:32:17'),
(8, 'example', 'equipment', 'Audio-Visual', 2, 'Good', 'anywhere', 'maintenance', '2026-11-07 13:47:28');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `eq_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `qty` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `date_from` date NOT NULL,
  `time_from` time DEFAULT NULL,
  `date_to` date NOT NULL,
  `time_to` time DEFAULT NULL,
  `purpose` varchar(500) NOT NULL,
  `status` enum('pending','approved','released','returned','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `note` varchar(500) DEFAULT NULL,
  `released_on` date DEFAULT NULL,
  `returned_on` date DEFAULT NULL,
  `return_condition` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `eq_id`, `user_id`, `qty`, `date_from`, `time_from`, `date_to`, `time_to`, `purpose`, `status`, `note`, `released_on`, `returned_on`, `return_condition`, `created_at`) VALUES
(1, 1, 3, 1, '2026-10-12', NULL, '2026-11-21', NULL, 'hey', 'returned', NULL, '2026-10-12', '2026-10-12', 'Good', '2026-10-12 06:22:32'),
(2, 2, 3, 1, '2026-10-12', NULL, '2026-10-13', NULL, 'qwe', 'pending', NULL, NULL, NULL, NULL, '2026-10-12 07:10:48'),
(3, 2, 3, 1, '2026-10-12', NULL, '2026-10-13', NULL, 'For Orientation', 'released', NULL, '2026-10-12', NULL, NULL, '2026-10-12 07:12:19'),
(4, 1, 3, 1, '2026-10-12', NULL, '2026-10-13', NULL, 'for games', 'returned', NULL, '2026-10-12', '2026-10-12', 'Fair', '2026-10-12 07:13:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `pw_hash` varchar(255) NOT NULL,
  `role` enum('admin','custodian','faculty','student','management') NOT NULL DEFAULT 'student',
  `dept` varchar(120) NOT NULL DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `pw_hash`, `role`, `dept`, `active`, `created_at`) VALUES
(1, 'Charles', 'jilliancharlesvillanueva143@gmail.com', '$2y$12$dDhESBu8cUGzXk8UFB.wjuRsPuc46Odg5cG8xjSK2Cowpz/65UkOe', 'student', 'BSIT', 1, '2026-10-12 06:08:17'),
(2, 'Admin', 'admin@example.com', '$2y$12$5RZ.8vX7krBIzY6N.XT1tu65PI.pyjfW3CZO5eDcawX7RhjIPPLRu', 'admin', 'IT Office', 1, '2026-10-12 06:13:44'),
(3, 'clark', 'clark@example.com', '$2y$12$gdpMgD77.S4KZ.U4PWXKCer3tJPdRT43CJqYbayD74dpTPjlXJ0ei', 'student', 'IT', 0, '2026-10-12 06:20:55'),
(4, 'Useruser', 'useruser@gmail.com', '$2y$12$.tl7IaPIAmU3uUWRDo0Gtu.g9FURwVn01fMCbT7K/pLDGbk9ROXx6', 'student', 'Bsit', 0, '2026-11-07 12:48:58'),
(5, 'Usernameuser12', 'useruser12@gmail.com', '$2y$12$7RQeddOFBzSoM0nq2GTDvelZ4fJkwUAB8gajdiLL54.15zEflhDQS', 'student', 'BSIT', 0, '2026-11-07 12:50:51'),
(6, 'Username123', 'username123@gmail.con', '$2y$12$KBZkC2Me.9c5RfPnE.3kHOZpGFuQvgLOleXEcnXQShqsdlPGlsSG.', 'student', 'BSBA', 1, '2026-11-07 12:58:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_requests_eq` (`eq_id`,`status`),
  ADD KEY `idx_requests_user` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `fk_requests_eq` FOREIGN KEY (`eq_id`) REFERENCES `equipment` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_requests_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
