/*
 * SMCBI EquiTrack – front end.
 * All data lives in MySQL. This file only draws the screens and calls
 * api/index.php (see api/ folder).
 */
'use strict';

const API = 'api/index.php';
const LOGO = 'assets/logo.jpg';

/* =====================================================================
 * Small helpers
 * ===================================================================== */

const $ = (selector) => document.querySelector(selector);
const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const day = (offset) => { const d = new Date(); d.setDate(d.getDate() + offset); return iso(d); };
const T = day(0); // today, as YYYY-MM-DD

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' };
const e = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ESC[c]);

/* =====================================================================
 * Talking to the server
 * ===================================================================== */

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function api(action, payload) {
  const options = { credentials: 'same-origin' };
  if (payload !== undefined) {
    options.method = 'POST';
    options.headers = { 'Content-Type': 'application/json' };
    options.body = JSON.stringify(payload);
  }

  let response;
  try {
    response = await fetch(`${API}?action=${action}`, options);
  } catch (err) {
    throw new ApiError('Cannot reach the server. Check your internet connection.', 0);
  }

  let data;
  try {
    data = JSON.parse(await response.text());
  } catch (err) {
    throw new ApiError('The server sent an unexpected reply. Check that the api folder is uploaded and PHP is running.', response.status);
  }
  if (!response.ok || data.error) {
    throw new ApiError(data.error || 'Request failed.', response.status);
  }
  return data;
}

/* =====================================================================
 * App state
 * ===================================================================== */

let U = null;                                   // signed-in user
let D = { eq: [], us: [], rq: [], shared: { n: 0, items: 0 } };  // data from the server
let PUB = { types: 0, units: 0 };               // numbers for the landing page
let FATAL = null;                               // connection error message
let V = 'dash';                                 // current tab
const S = { land: 1, reg: 0, q: '', cat: '', stf: '', rf: '', rep: 'inventory', ru: '', d1: '', d2: '' };

const staff = () => U && (U.role === 'admin' || U.role === 'custodian');
const borrower = () => U && (U.role === 'faculty' || U.role === 'student');

async function loadState() {
  const s = await api('state');
  U = s.user;
  D = { eq: s.eq, us: s.us, rq: s.rq, shared: s.shared };
}

function sessionEnded() {
  U = null;
  S.land = 0;
  S.reg = 0;
  R();
}

/** Calls a changing action, refreshes data, returns an error message or null. */
async function mutate(action, payload) {
  try {
    await api(action, payload);
    await loadState();
    return null;
  } catch (err) {
    if (err.status === 401) {
      sessionEnded();
      return 'Your session ended. Please sign in again.';
    }
    return err.message;
  }
}

/* =====================================================================
 * Equipment & Facility availability (same rules the server uses)
 * ===================================================================== */

const EQ = (id) => D.eq.find((x) => x.id === id) || { name: '(deleted)', qty: 0 };
const US = (id) => D.us.find((x) => x.id === id) || { name: '(deleted)', email: '' };
const rqById = (id) => D.rq.find((r) => r.id === id);

/** Helper to check if an item is a facility */
const isFacility = (x) => {
  if (!x) return false;
  const name = ((x.name || '') + ' ' + (x.cat || '') + ' ' + (x.type || '')).toLowerCase();
  return name.includes('facility') || name.includes('gym') || name.includes('avr') || name.includes('chapel') || name.includes('hall');
};

/** A released request that is past its due date. */
const od = (r) => r.st === 'released' && r.to < T;

/** Units of item `id` free for the period f..t. */
function free(id, f, t) {
  let used = 0;
  D.rq.forEach((r) => {
    if (r.eq === id && (r.st === 'approved' || r.st === 'released')) {
      const end = od(r) ? '9999' : r.to;
      if (r.from <= t && end >= f) used += r.qty;
    }
  });
  return EQ(id).qty - used;
}

function status(x) {
  if (x.st) return x.st;
  if (free(x.id, T, T) <= 0) {
    return D.rq.some((r) => r.eq === x.id && od(r)) ? 'overdue' : (isFacility(x) ? 'reserved' : 'borrowed');
  }
  return D.rq.some((r) => r.eq === x.id && r.st === 'approved') ? 'reserved' : 'available';
}

/* =====================================================================
 * Small UI pieces
 * ===================================================================== */

const pill = (s) => `<span class="p ${s}">${s}</span>`;

function tbl(headers, rows) {
  if (!rows.length) return '<div class="tw empty">Nothing to show yet.</div>';
  return `<div class="tw"><table>
    <thead><tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr></thead>
    <tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody>
  </table></div>`;
}

const btn = (action, id, label, cls = '') =>
  `<button class="b s ${cls}" data-a="${action}" data-i="${e(id)}">${label}</button>`;

/** Opens the pop-up form. `cb(values)` returns an error message, or nothing when it worked. */
function modal(title, fields, okLabel, cb) {
  const d = $('#m');
  const input = (f) => {
    if (f.o) {
      return `<select name="${f.n}">${f.o.map((o) => `<option ${o === f.v ? 'selected' : ''}>${e(o)}</option>`).join('')}</select>`;
    }
    if (f.t === 'area') {
      return `<textarea name="${f.n}" rows="3" placeholder="${e(f.p || '')}">${e(f.v)}</textarea>`;
    }
    return `<input name="${f.n}" type="${f.t || 'text'}" value="${e(f.v)}" ${f.min ? `min="${f.min}"` : ''} ${f.readonly ? 'readonly' : ''}>`;
  };

  d.innerHTML = `<form>
    <h3 style="margin-top:0">${title}</h3>
    ${fields.map((f) => `<label>${f.l}</label>${input(f)}`).join('')}
    <div class="err" role="alert"></div>
    <div class="row">
      <button type="button" class="b o" data-a="close">Cancel</button>
      ${okLabel ? `<button class="b">${okLabel}</button>` : ''}
    </div>
  </form>`;

  d.querySelector('form').onsubmit = async (ev) => {
    ev.preventDefault();
    const ok = ev.target.querySelector('button:not([type=button])');
    if (ok) ok.disabled = true;
    const values = Object.fromEntries(new FormData(ev.target));
    const message = await cb(values);
    if (ok) ok.disabled = false;
    if (message) {
      d.querySelector('.err').textContent = message;
    } else {
      d.close();
      R();
    }
  };
  d.showModal();
}

/** A simple message pop-up with only a Cancel button. */
function notice(title, message) {
  modal(title, [], '', () => {});
  $('#m .err').textContent = message;
}

/* =====================================================================
 * Icons
 * ===================================================================== */

const LEAF = '<svg viewBox="0 0 32 32" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 26C5 13 13 5 27 5c1 14-6 22-18 21"/><path d="M6 27C11 19 16 14 21 11"/></svg>';

const IC = {
  projector: '<rect x="5" y="17" width="38" height="16" rx="3"/><circle cx="32" cy="25" r="5"/><path d="M11 33v4M37 33v4M10 24h9"/>',
  laptop: '<rect x="10" y="10" width="28" height="20" rx="2"/><path d="M4 38h40l-3-8H7z"/>',
  microphone: '<rect x="18" y="5" width="12" height="20" rx="6"/><path d="M12 23a12 12 0 0 0 24 0M24 35v7M17 42h14"/>',
  cord: '<rect x="9" y="17" width="30" height="14" rx="3"/><path d="M17 22v4M24 22v4M31 22v4M3 24h6"/>',
  camera: '<rect x="5" y="14" width="38" height="24" rx="4"/><circle cx="24" cy="26" r="7"/><path d="M16 14l3-5h10l3 5"/>',
  multimeter: '<rect x="11" y="4" width="26" height="40" rx="4"/><rect x="16" y="9" width="16" height="9" rx="1"/><circle cx="24" cy="31" r="6"/><path d="M24 31l3-3"/>',
  speaker: '<rect x="11" y="4" width="26" height="40" rx="5"/><circle cx="24" cy="15" r="3"/><circle cx="24" cy="31" r="8"/>',
  microscope: '<path d="M19 7l10 4-5 14-10-4zM22 25v8M11 41h26M15 34a11 11 0 0 0 19-3"/>',
  cable: '<rect x="2" y="26" width="7" height="9" rx="1"/><rect x="39" y="15" width="7" height="9" rx="1"/><path d="M9 30c8-14 12 14 20 0s6-8 10-10"/>',
  tripod: '<rect x="18" y="4" width="12" height="9" rx="2"/><path d="M24 13v8M24 21L12 43M24 21l12 22M24 21v22"/>',
  building: '<path d="M6 42V10a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v32M22 20h18a2 2 0 0 1 2 2v20M6 42h38M11 14h3M16 14h3M11 20h3M16 20h3M11 26h3M16 26h3M11 32h3M16 32h3M27 26h3M33 26h3M27 32h3M33 32h3"/>',
  box: '<path d="M8 15l16-8 16 8v19l-16 8-16-8zM8 15l16 8 16-8M24 23v19"/>'
};

function pic(x, size) {
  const name = ((x.name || '') + ' ' + (x.cat || '') + ' ' + (x.type || '')).toLowerCase();
  let key = 'box';
  if (name.includes('gym') || name.includes('avr') || name.includes('chapel') || name.includes('facility') || name.includes('hall')) {
    key = 'building';
  } else {
    key = Object.keys(IC).find((k) => name.includes(k))
      || (name.includes('extension') ? 'cord' : name.includes('hdmi') ? 'cable' : 'box');
  }
  const style = size ? `style="width:${size}px;height:${size}px;border-radius:99px"` : '';
  return `<span class="pic" ${style}><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${IC[key]}</svg></span>`;
}

/* =====================================================================
 * Screens
 * ===================================================================== */

function vDash() {
  const B = borrower();
  const mine = D.rq.filter((r) => r.uid === U.id);
  const src = B ? mine : D.rq;
  const available = D.eq.reduce((a, x) => a + (x.st ? 0 : Math.max(0, free(x.id, T, T))), 0);
  const card = (n, label, cls = '') => `<div class="st ${cls}"><b>${n}</b><span>${label}</span></div>`;
  const pending = src.filter((r) => r.st === 'pending');
  const onLoan = src.filter((r) => r.st === 'released');
  const overdue = src.filter(od);

  let h = `<h2>${B ? 'My borrowing & reservations' : 'Dashboard'}</h2>
    <div class="eco">${LEAF}<div><b>Share more, buy less.</b><br>
      <span class="mut">${D.shared.n} borrowings & facility bookings (${D.shared.items} items) shared so far. Every reused item is one less purchase and less waste.</span></div></div>`;

  if (B && overdue.length) {
    h += `<div class="alert"><b>Overdue notice:</b> ${overdue.map((r) => e(EQ(r.eq).name) + ' was due ' + r.to).join('; ')}. Please return it to the equipment custodian.</div>`;
  }

  h += `<div class="grid">
    ${B ? '' : card(D.eq.reduce((a, x) => a + x.qty, 0), 'Total units/facilities')}
    ${card(available, 'Available now')}
    ${card(pending.length, 'Pending requests', pending.length ? 'acc' : '')}
    ${card(onLoan.length, 'On loan / in use')}
    ${card(overdue.length, 'Overdue', overdue.length ? 'bad' : '')}
  </div>`;

  if (staff()) {
    h += '<h3>Needs action</h3>' + reqTbl(D.rq.filter((r) => r.st === 'pending' || r.st === 'approved'));
  } else if (B) {
    h += '<h3>Recent requests</h3>' + reqTbl(mine.slice(-5).reverse());
  }
  if (!B) h += '<h3>Overdue equipment</h3>' + odTbl();
  return h;
}

function reqTbl(list) {
  const rows = list.map((r) => {
    let actions = '';
    if (staff()) {
      if (r.st === 'pending') actions = btn('approve', r.id, 'Approve') + btn('reject', r.id, 'Reject', 'd');
      if (r.st === 'approved') actions = btn('release', r.id, 'Release / Open venue') + btn('reject', r.id, 'Cancel', 'd');
      if (r.st === 'released') actions = btn('ret', r.id, 'Record return / Close');
    } else if (r.uid === U.id && r.st === 'pending') {
      actions = btn('cancel', r.id, 'Cancel request', 'd');
    }
    const item = EQ(r.eq);
    return [
      r.id,
      e(US(r.uid).name),
      pic(item, 30) + ' ' + e(item.name),
      r.qty,
      r.from + ' to ' + r.to,
      e(r.purpose) + (r.note ? `<div class="mut">Note: ${e(r.note)}</div>` : ''),
      pill(od(r) ? 'overdue' : r.st),
      actions,
    ];
  });
  return tbl(['ID', 'Borrower', 'Equipment / Facility', 'Qty', 'Period', 'Purpose', 'Status', ''], rows);
}

const daysLate = (r) => Math.round((new Date(T) - new Date(r.to)) / 864e5);

function odTbl() {
  return tbl(
    ['Request', 'Borrower', 'Contact', 'Equipment / Facility', 'Qty', 'Due', 'Days late'],
    D.rq.filter(od).map((r) => {
      const u = US(r.uid);
      return [r.id, e(u.name), e(u.email), e(EQ(r.eq).name), r.qty, r.to, daysLate(r)];
    })
  );
}

function vEq() {
  const cats = [...new Set(D.eq.map((x) => x.cat))];
  if (!cats.includes('Facility')) cats.push('Facility');
  
  const q = S.q.toLowerCase();
  const list = D.eq.filter((x) =>
    (!q || (x.name + x.id + x.loc + x.cat).toLowerCase().includes(q)) &&
    (!S.cat || x.cat === S.cat) &&
    (!S.stf || status(x) === S.stf));

  const statuses = ['available', 'borrowed', 'reserved', 'overdue', 'maintenance', 'unavailable'];
  let h = `<h2>${borrower() ? 'Browse inventory & facilities' : 'Inventory & Facility management'}</h2>
    <div class="bar">
      <input id="q" placeholder="Search name, ID, location" value="${e(S.q)}">
      <select id="cat"><option value="">All categories</option>${cats.map((c) => `<option ${c === S.cat ? 'selected' : ''}>${e(c)}</option>`).join('')}</select>
      <select id="stf"><option value="">All statuses</option>${statuses.map((s) => `<option ${s === S.stf ? 'selected' : ''}>${s}</option>`).join('')}</select>
      ${staff() ? btn('eqAdd', '', 'Add item / facility') : ''}
    </div>`;

  if (!list.length) return h + '<div class="tw empty">No equipment or facilities match your filters.</div>';

  h += '<div class="eqs">' + list.map((x) => {
    const s = status(x);
    const f = x.st ? 0 : Math.max(0, free(x.id, T, T));
    const facility = isFacility(x);
    
    let actions = '';
    if (borrower() && !x.st && x.qty > 0) {
      actions = btn('borrow', x.id, facility ? 'Reserve facility' : 'Request to borrow');
    }
    if (staff()) actions = btn('eqEdit', x.id, 'Edit', 'o') + btn('eqDel', x.id, 'Delete', 'd');
    
    return `<div class="eqc">${pic(x)}<div class="in">
      <b>${e(x.name)}</b>
      <span class="mut">${x.id} · ${e(x.cat)}</span>
      <span>${facility ? 'Venue' : f + ' of ' + x.qty + ' free'} · ${e(x.cond)}</span>
      <span class="mut">${e(x.loc)}</span>
      <div>${pill(s)}</div>
      <div class="ac">${actions}</div>
    </div></div>`;
  }).join('') + '</div>';
  return h;
}

function vReq() {
  const list = D.rq
    .filter((r) => (staff() ? true : r.uid === U.id) && (!S.rf || (S.rf === 'overdue' ? od(r) : r.st === S.rf)))
    .reverse();
  const statuses = ['pending', 'approved', 'released', 'returned', 'rejected', 'cancelled', 'overdue'];
  return `<h2>${staff() ? 'Borrowing & reservation requests' : 'My requests'}</h2>
    <div class="bar">
      <select id="rf"><option value="">All statuses</option>${statuses.map((s) => `<option ${s === S.rf ? 'selected' : ''}>${s}</option>`).join('')}</select>
      ${borrower() ? btn('newReq', '', 'New request') : ''}
    </div>` + reqTbl(list);
}

/* ---------- reports ---------- */

function report() {
  const inRange = (r) => (!S.d1 || r.from >= S.d1) && (!S.d2 || r.from <= S.d2);
  const rr = D.rq.filter(inRange);
  const stOf = (r) => (od(r) ? 'overdue' : r.st);
  let c, rows;

  switch (S.rep) {
    case 'inventory':
      c = ['ID', 'Name / Venue', 'Category', 'Total', 'Free', 'Condition', 'Location', 'Status'];
      rows = D.eq.map((x) => [x.id, x.name, x.cat, x.qty, x.st ? 0 : Math.max(0, free(x.id, T, T)), x.cond, x.loc, status(x)]);
      break;
    case 'transactions':
      c = ['Request', 'Borrower', 'Item / Venue', 'Qty', 'From', 'To', 'Purpose', 'Status'];
      rows = rr.map((r) => [r.id, US(r.uid).name, EQ(r.eq).name, r.qty, r.from, r.to, r.purpose, stOf(r)]);
      break;
    case 'returns':
      c = ['Request', 'Borrower', 'Item / Venue', 'Qty', 'Due', 'Returned on', 'Condition', 'Notes'];
      rows = rr.filter((r) => r.st === 'returned')
        .map((r) => [r.id, US(r.uid).name, EQ(r.eq).name, r.qty, r.to, r.ret, r.cond, r.note || '']);
      break;
    case 'overdue':
      c = ['Request', 'Borrower', 'Item / Venue', 'Qty', 'Due', 'Days late'];
      rows = D.rq.filter(od).map((r) => [r.id, US(r.uid).name, EQ(r.eq).name, r.qty, r.to, daysLate(r)]);
      break;
    case 'borrower':
      c = ['Request', 'Item / Venue', 'Qty', 'From', 'To', 'Purpose', 'Status'];
      rows = rr.filter((r) => r.uid === (S.ru || D.us[0].id))
        .map((r) => [r.id, EQ(r.eq).name, r.qty, r.from, r.to, r.purpose, stOf(r)]);
      break;
    default: // usage
      c = ['Item / Venue', 'Times reserved', 'Units used', 'Currently out'];
      rows = D.eq.map((x) => {
        const m = rr.filter((r) => r.eq === x.id && ['released', 'returned'].includes(r.st));
        const out = D.rq.filter((r) => r.eq === x.id && r.st === 'released').reduce((a, r) => a + r.qty, 0);
        return [x.name, m.length, m.reduce((a, r) => a + r.qty, 0), out];
      });
  }
  return { c, rows };
}

function vRep() {
  const r = report();
  const kinds = [
    ['inventory', 'Inventory & Facility list'], ['transactions', 'Borrowing & reservation transactions'], ['returns', 'Completed returns'],
    ['overdue', 'Overdue items'], ['borrower', 'Borrower history'], ['usage', 'Item & Facility usage'],
  ];
  return `<h2>Reports</h2>
    <div class="bar">
      <select id="rep">${kinds.map((o) => `<option value="${o[0]}" ${o[0] === S.rep ? 'selected' : ''}>${o[1]}</option>`).join('')}</select>
      ${S.rep === 'borrower' ? `<select id="ru">${D.us.map((u) => `<option value="${u.id}" ${u.id === S.ru ? 'selected' : ''}>${e(u.name)}</option>`).join('')}</select>` : ''}
      <label class="mut">From <input type="date" id="d1" value="${S.d1}"></label>
      <label class="mut">To <input type="date" id="d2" value="${S.d2}"></label>
      ${btn('print', '', 'Print', 'o')}${btn('csv', '', 'Copy CSV', 'o')}
    </div>
    <div class="mut" style="margin-bottom:8px">Generated ${T}</div>` + tbl(r.c, r.rows.map((x) => x.map(e)));
}

function vUsers() {
  const roles = ['admin', 'custodian', 'faculty', 'student', 'management'];
  return `<h2>User management</h2><div class="bar">${btn('uAdd', '', 'Add user')}</div>` +
    tbl(['Name', 'Email', 'Role', 'Department', 'Status', ''], D.us.map((u) => [
      e(u.name),
      e(u.email),
      `<select data-a="uRole" data-i="${u.id}" ${u.id === U.id ? 'disabled' : ''}>${roles.map((r) => `<option ${r === u.role ? 'selected' : ''}>${r}</option>`).join('')}</select>`,
      e(u.dept),
      pill(u.active ? 'available' : 'inactive'),
      u.id === U.id ? '' : btn('uToggle', u.id, u.active ? 'Deactivate' : 'Activate', u.active ? 'd' : ''),
    ]));
}

/* ---------- landing and sign-in ---------- */

function vLand() {
  const features = [
    ['building', 'Reserve facilities', 'Book the school gymnasium, AVR, chapel, and other campus venues online.'],
    ['projector', 'Check availability', 'See which equipment or facility is free before planning your event.'],
    ['laptop', 'Request online', 'Pick the item or venue, dates, and purpose without paper forms.'],
    ['box', 'Keep records', 'Every transaction, reservation, and report organized in one place.'],
  ];
  const steps = [
    ['Browse', 'Find the equipment or facility you need and check availability.'],
    ['Request', 'Choose your dates, quantity/venue, and state the purpose.'],
    ['Pick up / Access', 'Once approved, the custodian releases equipment or unlocks the facility.'],
    ['Return / Clear', 'Complete your event on time so others can use the space.'],
  ];
  const roles = [
    ['Students and faculty', 'Browse equipment and facilities, submit request for approval.'],
    ['Equipment custodians', 'Approve requests, manage facility schedules, release/receive equipment.'],
    ['Administrators', 'Manage users, equipment inventory, facilities, and reports.'],
    ['School management', 'View analytics, utilization rates, and generated reports.'],
  ];
  return `<div class="hero">
      <div class="top"><img class="logo" style="width:42px;height:42px;margin:0;border-width:2px" src="${LOGO}" alt=""><b>SMCBI EquiTrack</b>
        <button class="b" data-a="goLogin">Sign in</button></div>
      <img class="logo" src="${LOGO}" alt="St. Mary's College of Bansalan seal">
      <h1>Campus resources, ready when you need them.</h1>
      <p>Request equipment and reserve school facilities like the gym, AVR, and chapel in one simple place.</p>
      <button class="b w" data-a="goLogin">Sign in</button>
      <button class="b" data-a="goReg">Create an account</button>
      <div style="margin-top:16px;opacity:.85">${PUB.types} equipment & facility types, ${PUB.units} total units in the system</div>
    </div>
    <div class="sec"><h2>What SMCBI EquiTrack does</h2><div class="cols">${features.map((f) =>
      `<div class="fc">${pic({ name: f[0] }, 52)}<h3>${f[1]}</h3><p>${f[2]}</p></div>`).join('')}</div></div>
    <div class="sec"><h2>How borrowing & booking works</h2><div class="cols">${steps.map((x, i) =>
      `<div class="fc"><span class="num">${i + 1}</span><h3>${x[0]}</h3><p>${x[1]}</p></div>`).join('')}</div></div>
    <div class="sec"><h2>Made for everyone who shares campus resources</h2><div class="cols">${roles.map((x) =>
      `<div class="fc"><h3>${x[0]}</h3><p>${x[1]}</p></div>`).join('')}</div></div>
    <div class="sec"><div class="eco">${LEAF}<div><b>Share more, buy less.</b><br>
      <span class="mut">Sharing equipment and venues maximizes campus resource use.</span></div></div></div>
    <div class="foot"><img class="logo" style="width:56px;height:56px" src="${LOGO}" alt=""><br>
      St. Mary's College of Bansalan, Inc.<br>Bansalan, Davao del Sur, Philippines</div>`;
}

function vLogin(register) {
  return `<div class="login"><div class="card">
    <div class="lg"><img class="logo" src="${LOGO}" alt="St. Mary's College of Bansalan seal">
      <h1 style="margin:8px 0 2px;justify-content:center">SMCBI EquiTrack</h1>
      <p class="mut" style="margin-top:0">St. Mary's College of Bansalan, Inc.<br>Equipment & Facility system</p></div>
    ${register ? `<input id="rn" placeholder="Full name"><input id="rd" placeholder="Department / course">
      <select id="rr" style="width:100%;margin-bottom:10px"><option>student</option><option>faculty</option></select>` : ''}
    <input id="em" type="email" placeholder="Email" autocomplete="username">
    <input id="pw" type="password" placeholder="Password" autocomplete="${register ? 'new-password' : 'current-password'}">
    <div class="err" id="le" role="alert"></div>
    <button class="b" style="width:100%" data-a="${register ? 'register' : 'login'}">${register ? 'Create account' : 'Sign in'}</button>
    <p style="text-align:center"><button class="b s o" data-a="${register ? 'toLogin' : 'toReg'}">${register ? 'Back to sign in' : 'Register an account'}</button></p>
    <p style="text-align:center;margin:0"><button class="b s o" data-a="home">Back to home</button></p>
    ${register ? '<p class="mut">New accounts are activated by an administrator.</p>' : ''}
  </div></div>`;
}

function vFatal() {
  return `<div class="login"><div class="card">
    <h1>Cannot reach the server</h1>
    <p class="mut">${e(FATAL)}</p>
    <button class="b" data-a="retry">Try again</button>
  </div></div>`;
}

/* ---------- page shell ---------- */

const NAV = {
  admin: [['dash', 'Dashboard'], ['eq', 'Inventory & Facilities'], ['req', 'Requests'], ['od', 'Overdue'], ['rep', 'Reports'], ['users', 'Users']],
  custodian: [['dash', 'Dashboard'], ['eq', 'Inventory & Facilities'], ['req', 'Requests'], ['od', 'Overdue'], ['rep', 'Reports']],
  faculty: [['dash', 'Home'], ['eq', 'Browse resources'], ['req', 'My requests']],
  student: [['dash', 'Home'], ['eq', 'Browse resources'], ['req', 'My requests']],
  management: [['dash', 'Dashboard'], ['eq', 'Inventory & Facilities'], ['od', 'Overdue'], ['rep', 'Reports']],
};

function R() {
  const app = $('#app');
  if (FATAL) { app.innerHTML = vFatal(); return; }
  if (!U) { app.innerHTML = S.land ? vLand() : vLogin(S.reg); return; }

  const nav = NAV[U.role];
  if (!nav.some((n) => n[0] === V)) V = 'dash';
  const views = {
    dash: vDash, eq: vEq, req: vReq, od: () => '<h2>Overdue equipment</h2>' + odTbl(), rep: vRep, users: vUsers,
  };
  const light = 'style="color:var(--on);border-color:var(--on)"';
  app.innerHTML = `<header>
      <h1><img class="logo" src="${LOGO}" alt="SMCBI seal">SMCBI EquiTrack</h1>
      <small>${e(U.name)} (${U.role})</small>
      <button class="b o" ${light} data-a="prof">Profile</button>
      <button class="b o" ${light} data-a="logout">Sign out</button>
    </header>
    <nav>${nav.map((n) => `<button class="${n[0] === V ? 'on' : ''}" data-a="nav" data-i="${n[0]}">${n[1]}</button>`).join('')}</nav>
    <main>${views[V]()}</main>`;
}

/* =====================================================================
 * Forms
 * ===================================================================== */

function eqForm(x) {
  const isNew = !x;
  x = x || { name: '', cat: 'Audio-Visual', qty: 1, cond: 'Good', loc: '', st: '' };
  modal(isNew ? 'Add item or facility' : 'Edit item or facility', [
    { n: 'name', l: 'Name / Venue title', v: x.name },
    { n: 'cat', l: 'Category (use "Facility" for Gym, AVR, Chapel)', v: x.cat },
    { n: 'qty', l: 'Total quantity (1 for facilities)', t: 'number', v: x.qty, min: 0 },
    { n: 'cond', l: 'Condition', o: ['Good', 'Fair', 'Poor', 'Damaged'], v: x.cond },
    { n: 'loc', l: 'Location', v: x.loc },
    { n: 'st', l: 'Manual status', o: ['(automatic)', 'maintenance', 'unavailable'], v: x.st || '(automatic)' },
  ], 'Save', (o) => {
    if (!o.name.trim() || !o.cat.trim()) return 'Name and category are required.';
    const qty = parseInt(o.qty, 10);
    if (!(qty >= 0)) return 'Quantity must be 0 or more.';
    return mutate('eq_save', {
      id: isNew ? '' : x.id,
      name: o.name, cat: o.cat, qty, cond: o.cond, loc: o.loc,
      st: o.st === '(automatic)' ? '' : o.st,
    });
  });
}

function reqForm(id) {
  const items = D.eq.filter((x) => !x.st && x.qty > 0);
  if (!items.length) return notice('No resources available', 'There are no equipment items or facilities currently available to request.');
  id = id || (items[0] && items[0].id);
  const label = (x) => `${x.id} – ${x.name}`;
  const chosen = items.find((x) => x.id === id);
  const facility = isFacility(chosen);

  modal(facility ? `Reserve ${chosen.name}` : 'Request equipment', [
    { n: 'eq', l: 'Equipment / Facility', o: items.map(label), v: chosen && label(chosen) },
    { n: 'qty', l: facility ? 'Quantity (Venue)' : 'Quantity', t: 'number', v: 1, min: 1, readonly: facility },
    { n: 'from', l: facility ? 'Reservation start date' : 'Borrow date', t: 'date', v: T, min: T },
    { n: 'to', l: facility ? 'Reservation end date' : 'Return date', t: 'date', v: day(1), min: T },
    { n: 'purpose', l: 'Purpose of use', t: 'area', p: facility ? 'e.g., Mass service, Basketball practice, Seminar' : 'e.g., Classroom presentation', v: '' },
  ], facility ? 'Submit reservation' : 'Submit request', (o) => {
    const eid = (o.eq || '').split(' – ')[0];
    const qty = parseInt(o.qty, 10);
    if (!eid) return 'There is no item or facility selected.';
    if (!(qty >= 1)) return 'Enter a quantity of at least 1.';
    if (o.from < T) return 'Date cannot be in the past.';
    if (o.to < o.from) return 'End date must be on or after the start date.';
    if (!o.purpose.trim()) return 'Please state the purpose.';
    const f = free(eid, o.from, o.to);
    if (qty > f) return facility ? 'The facility is already reserved for those dates.' : `Only ${Math.max(0, f)} unit(s) free for those dates.`;
    return mutate('rq_create', { eq: eid, qty, from: o.from, to: o.to, purpose: o.purpose });
  });
}

function userForm() {
  modal('Add user', [
    { n: 'name', l: 'Full name', v: '' },
    { n: 'email', l: 'Email', t: 'email', v: '' },
    { n: 'pw', l: 'Temporary password', v: '' },
    { n: 'role', l: 'Role', o: ['student', 'faculty', 'custodian', 'management', 'admin'], v: 'student' },
    { n: 'dept', l: 'Department', v: '' },
  ], 'Add user', (o) => {
    if (!o.name.trim() || !o.email.trim() || o.pw.length < 6) return 'Name, email and a password of 6+ characters are required.';
    return mutate('user_add', { name: o.name, email: o.email, password: o.pw, role: o.role, dept: o.dept });
  });
}

/* =====================================================================
 * Button actions (data-a="name")
 * ===================================================================== */

/** Runs a one-click action; shows a pop-up if the server refuses. */
async function simple(action, id, errorTitle) {
  const message = await mutate(action, { id });
  if (message) notice(errorTitle, message);
  else R();
}

const ACT = {
  close() { $('#m').close(); },
  goLogin() { S.land = 0; S.reg = 0; R(); },
  goReg() { S.land = 0; S.reg = 1; R(); },
  home() { S.land = 1; R(); },
  toReg() { S.reg = 1; R(); },
  toLogin() { S.reg = 0; R(); },
  nav(i) { V = i; R(); },
  retry() { FATAL = null; boot(); },

  async login() {
    const err = $('#le');
    err.className = 'err';
    err.textContent = '';
    try {
      await api('login', { email: $('#em').value.trim(), password: $('#pw').value });
      await loadState();
      V = 'dash';
      R();
    } catch (ex) {
      err.textContent = ex.message;
    }
  },

  async register() {
    const err = $('#le');
    err.className = 'err';
    err.textContent = '';
    const name = $('#rn').value.trim();
    const email = $('#em').value.trim();
    const password = $('#pw').value;
    if (!name || !email || password.length < 6) {
      err.textContent = 'Enter your name, email and a password of 6+ characters.';
      return;
    }
    try {
      await api('register', { name, email, password, dept: $('#rd').value, role: $('#rr').value });
      S.reg = 0;
      R();
      const done = $('#le');
      done.className = 'err ok';
      done.textContent = 'Account created. An administrator must activate it before you sign in.';
    } catch (ex) {
      err.textContent = ex.message;
    }
  },

  async logout() {
    try { await api('logout', {}); } catch (ex) { /* signing out anyway */ }
    U = null;
    D = { eq: [], us: [], rq: [], shared: { n: 0, items: 0 } };
    S.land = 1;
    R();
  },

  prof() {
    modal('Profile', [
      { n: 'name', l: 'Name', v: U.name },
      { n: 'dept', l: 'Department', v: U.dept },
      { n: 'pw', l: 'New password (leave blank to keep)', t: 'password', v: '' },
    ], 'Save', (o) => {
      if (!o.name.trim()) return 'Name is required.';
      if (o.pw && o.pw.length < 6) return 'Password needs 6+ characters.';
      return mutate('profile', { name: o.name, dept: o.dept, password: o.pw });
    });
  },

  eqAdd() { eqForm(); },
  eqEdit(i) { eqForm(EQ(i)); },
  eqDel(i) {
    if (D.rq.some((r) => r.eq === i && ['pending', 'approved', 'released'].includes(r.st))) {
      return notice('Cannot delete', 'This item/facility has active requests or reservations.');
    }
    modal('Delete ' + e(EQ(i).name) + '?', [], 'Delete', () => mutate('eq_delete', { id: i }));
  },

  borrow(i) { reqForm(i); },
  newReq() { reqForm(); },

  approve(i) { return simple('rq_approve', i, 'Cannot approve'); },
  release(i) { return simple('rq_release', i, 'Cannot release'); },
  cancel(i) { return simple('rq_cancel', i, 'Cannot cancel'); },

  reject(i) {
    const r = rqById(i);
    modal(r.st === 'approved' ? 'Cancel approved request' : 'Reject request',
      [{ n: 'note', l: 'Reason', t: 'area', v: '' }], 'Confirm', (o) => {
        if (!o.note.trim()) return 'A reason is required.';
        return mutate('rq_reject', { id: i, note: o.note });
      });
  },

  ret(i) {
    modal('Record completion / return', [
      { n: 'cond', l: 'Condition after use', o: ['Good', 'Fair', 'Damaged', 'Lost'], v: 'Good' },
      { n: 'note', l: 'Notes', t: 'area', v: '' },
    ], 'Mark completed', (o) => mutate('rq_return', { id: i, cond: o.cond, note: o.note }));
  },

  uAdd() { userForm(); },
  async uToggle(i) {
    const message = await mutate('user_toggle', { id: i });
    if (message) notice('Cannot change user', message);
    else R();
  },

  print() { window.print(); },
  csv() {
    const r = report();
    const quote = (v) => '"' + String(v ?? '').replace(/"/g, '""') + '"';
    const text = [r.c, ...r.rows].map((row) => row.map(quote).join(',')).join('\n');
    modal('CSV data', [], '', () => {});
    $('#m form').insertAdjacentHTML('afterbegin', `<textarea id="ct" rows="8" readonly>${e(text)}</textarea>`);
    $('#ct').select();
    try { navigator.clipboard.writeText(text); } catch (ex) { /* copy is optional */ }
  },
};

/* =====================================================================
 * Events
 * ===================================================================== */

document.addEventListener('click', (ev) => {
  const b = ev.target.closest('button[data-a]');
  if (!b || b.tagName !== 'BUTTON' || !ACT[b.dataset.a]) return;
  Promise.resolve(ACT[b.dataset.a](b.dataset.i)).catch((err) => notice('Something went wrong', err.message));
});

document.addEventListener('input', (ev) => {
  const t = ev.target;
  if (t.id !== 'q') return;
  const start = t.selectionStart;
  const end = t.selectionEnd;
  S.q = t.value;
  R();
  const search = $('#q');
  if (search) {
    search.focus();
    search.setSelectionRange(start, end);
  }
});

document.addEventListener('change', async (ev) => {
  const t = ev.target;

  // Admin changes someone's role.
  if (t.dataset.a === 'uRole' && U && U.role === 'admin') {
    const message = await mutate('user_role', { id: t.dataset.i, role: t.value });
    if (message) notice('Cannot change role', message);
    R();
    return;
  }

  // Filters and report options.
  const filters = ['cat', 'stf', 'rf', 'rep', 'ru', 'd1', 'd2'];
  if (filters.includes(t.id)) {
    S[t.id] = t.value;
    R();
    const again = document.getElementById(t.id);
    if (again && again.tagName === 'INPUT' && again.type === 'text') {
      again.focus();
      again.setSelectionRange(again.value.length, again.value.length);
    }
  }
});

document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter' && !U && ev.target.tagName === 'INPUT') {
    (S.reg ? ACT.register : ACT.login)();
  }
});

// Pick up changes made by other people when coming back to this tab.
document.addEventListener('visibilitychange', () => {
  if (document.hidden || !U || $('#m').open) return;
  loadState().then(R).catch((err) => { if (err.status === 401) sessionEnded(); });
});

/* =====================================================================
 * Start
 * ===================================================================== */

async function boot() {
  try {
    PUB = await api('public');
    const me = await api('me');
    if (me.user) await loadState();
  } catch (err) {
    FATAL = err.message;
  }
  R();
}

boot();