<?php
/*
 * SMCBI EquiTrack API. One endpoint: api/index.php?action=NAME
 *   GET  actions: public, me, state
 *   POST actions: everything else (JSON body)
 */

require __DIR__ . '/db.php';

set_exception_handler(function ($e) {
    error_log('EquiTrack error: ' . $e->getMessage());
    fail('Something went wrong on the server. Please try again.', 500);
});

$action = isset($_GET['action']) ? (string) $_GET['action'] : '';
$method = $_SERVER['REQUEST_METHOD'];
$reads  = array('public', 'me', 'state');

if (in_array($action, $reads, true)) {
    if ($method !== 'GET') {
        fail('Method not allowed.', 405);
    }
} else {
    if ($method !== 'POST') {
        fail('Method not allowed.', 405);
    }
    // Only accept JSON posts. A web form on another site cannot send this
    // content type, which blocks cross-site request forgery.
    $ct = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (stripos($ct, 'application/json') !== 0) {
        fail('Unsupported content type.', 415);
    }
}

switch ($action) {
    case 'public':      action_public();      break;
    case 'me':          action_me();          break;
    case 'state':       action_state();       break;
    case 'login':       action_login();       break;
    case 'register':    action_register();    break;
    case 'logout':      action_logout();      break;
    case 'profile':     action_profile();     break;
    case 'eq_save':     action_eq_save();     break;
    case 'eq_delete':   action_eq_delete();   break;
    case 'rq_create':   action_rq_create();   break;
    case 'rq_approve':  action_rq_approve();  break;
    case 'rq_reject':   action_rq_reject();   break;
    case 'rq_release':  action_rq_release();  break;
    case 'rq_return':   action_rq_return();   break;
    case 'rq_cancel':   action_rq_cancel();   break;
    case 'user_add':    action_user_add();    break;
    case 'user_role':   action_user_role();   break;
    case 'user_toggle': action_user_toggle(); break;
    default:            fail('Unknown action.', 404);
}

/* =====================================================================
 * Reading
 * ===================================================================== */

function action_public()
{
    $row = db()->query('SELECT COUNT(*) AS types, COALESCE(SUM(qty), 0) AS units FROM equipment')->fetch();
    json_out(array('types' => (int) $row['types'], 'units' => (int) $row['units']));
}

function action_me()
{
    $u = current_user();
    json_out(array('user' => $u ? fmt_user($u) : null));
}

function action_state()
{
    $u   = require_user();
    $pdo = db();

    $equipment = array();
    foreach ($pdo->query('SELECT * FROM equipment ORDER BY id')->fetchAll() as $r) {
        $equipment[] = fmt_equipment($r);
    }

    $seesAll  = in_array($u['role'], array('admin', 'custodian', 'management'), true);
    $users    = array();
    $requests = array();

    if ($seesAll) {
        foreach ($pdo->query('SELECT * FROM users ORDER BY id')->fetchAll() as $r) {
            $users[] = fmt_user($r);
        }
        foreach ($pdo->query('SELECT * FROM requests ORDER BY id')->fetchAll() as $r) {
            $requests[] = fmt_request($r);
        }
    } else {
        $users[] = fmt_user($u);
        // Borrowers see their own requests in full. Other people's approved or
        // released requests are sent without names so availability is correct.
        $own = $pdo->prepare('SELECT * FROM requests WHERE user_id = ? ORDER BY id');
        $own->execute(array($u['id']));
        foreach ($own->fetchAll() as $r) {
            $requests[] = fmt_request($r);
        }
        $others = $pdo->prepare("SELECT * FROM requests WHERE user_id <> ? AND status IN ('approved','released')");
        $others->execute(array($u['id']));
        foreach ($others->fetchAll() as $r) {
            $requests[] = fmt_request($r, true);
        }
    }

    $shared = $pdo->query(
        "SELECT COUNT(*) AS n, COALESCE(SUM(qty), 0) AS items FROM requests WHERE status IN ('released','returned')"
    )->fetch();

    json_out(array(
        'user'   => fmt_user($u),
        'eq'     => $equipment,
        'us'     => $users,
        'rq'     => $requests,
        'shared' => array('n' => (int) $shared['n'], 'items' => (int) $shared['items']),
    ));
}

/* =====================================================================
 * Accounts
 * ===================================================================== */

function action_login()
{
    $d     = body();
    $email = strtolower(text($d, 'email', 190));
    $pass  = isset($d['password']) && is_string($d['password']) ? $d['password'] : '';

    $st = db()->prepare('SELECT * FROM users WHERE email = ?');
    $st->execute(array($email));
    $u = $st->fetch();

    if (!$u || !password_verify($pass, $u['pw_hash'])) {
        usleep(400000); // slow down password guessing
        fail('Email or password is incorrect.', 401);
    }
    if (!$u['active']) {
        fail('This account is inactive. Ask an administrator to activate it.', 403);
    }

    start_session();
    session_regenerate_id(true);
    $_SESSION['uid'] = (int) $u['id'];
    json_out(array('ok' => true));
}

function action_logout()
{
    start_session();
    $_SESSION = array();
    session_destroy();
    json_out(array('ok' => true));
}

function action_register()
{
    $d     = body();
    $name  = text($d, 'name', 120);
    $email = strtolower(text($d, 'email', 190));
    $dept  = text($d, 'dept', 120);
    $pass  = isset($d['password']) && is_string($d['password']) ? $d['password'] : '';
    $role  = (isset($d['role']) && $d['role'] === 'faculty') ? 'faculty' : 'student';

    if ($name === '' || $email === '' || strlen($pass) < 6) {
        fail('Enter your name, email and a password of 6+ characters.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('Enter a valid email address.');
    }
    insert_user($name, $email, $pass, $role, $dept, 0);
    json_out(array('ok' => true));
}

function insert_user($name, $email, $pass, $role, $dept, $active)
{
    $pdo = db();
    $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $chk->execute(array($email));
    if ($chk->fetch()) {
        fail('That email is already registered.');
    }
    $ins = $pdo->prepare('INSERT INTO users (name, email, pw_hash, role, dept, active) VALUES (?, ?, ?, ?, ?, ?)');
    $ins->execute(array($name, $email, password_hash($pass, PASSWORD_DEFAULT), $role, $dept, $active));
}

function action_profile()
{
    $u    = require_user();
    $d    = body();
    $name = text($d, 'name', 120);
    $dept = text($d, 'dept', 120);
    $pass = isset($d['password']) && is_string($d['password']) ? $d['password'] : '';

    if ($name === '') {
        fail('Name is required.');
    }
    if ($pass !== '' && strlen($pass) < 6) {
        fail('Password needs 6+ characters.');
    }
    $pdo = db();
    $pdo->prepare('UPDATE users SET name = ?, dept = ? WHERE id = ?')->execute(array($name, $dept, $u['id']));
    if ($pass !== '') {
        $pdo->prepare('UPDATE users SET pw_hash = ? WHERE id = ?')
            ->execute(array(password_hash($pass, PASSWORD_DEFAULT), $u['id']));
    }
    json_out(array('ok' => true));
}

function action_user_add()
{
    require_role(array('admin'));
    $d     = body();
    $name  = text($d, 'name', 120);
    $email = strtolower(text($d, 'email', 190));
    $dept  = text($d, 'dept', 120);
    $pass  = isset($d['password']) && is_string($d['password']) ? $d['password'] : '';
    $role  = isset($d['role']) ? $d['role'] : '';

    if (!in_array($role, array('student', 'faculty', 'custodian', 'management', 'admin'), true)) {
        fail('Choose a role.');
    }
    if ($name === '' || $email === '' || strlen($pass) < 6) {
        fail('Name, email and a password of 6+ characters are required.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('Enter a valid email address.');
    }
    insert_user($name, $email, $pass, $role, $dept, 1);
    json_out(array('ok' => true));
}

function action_user_role()
{
    $me = require_role(array('admin'));
    $d  = body();
    $id = num(isset($d['id']) ? $d['id'] : '');
    $role = isset($d['role']) ? $d['role'] : '';

    if (!in_array($role, array('student', 'faculty', 'custodian', 'management', 'admin'), true)) {
        fail('Choose a role.');
    }
    if ($id === (int) $me['id']) {
        fail('You cannot change your own role.');
    }
    $st = db()->prepare('UPDATE users SET role = ? WHERE id = ?');
    $st->execute(array($role, $id));
    json_out(array('ok' => true));
}

function action_user_toggle()
{
    $me = require_role(array('admin'));
    $d  = body();
    $id = num(isset($d['id']) ? $d['id'] : '');
    if ($id === (int) $me['id']) {
        fail('You cannot deactivate your own account.');
    }
    db()->prepare('UPDATE users SET active = 1 - active WHERE id = ?')->execute(array($id));
    json_out(array('ok' => true));
}

/* =====================================================================
 * Equipment
 * ===================================================================== */

function action_eq_save()
{
    require_role(array('admin', 'custodian'));
    $d    = body();
    $name = text($d, 'name', 120);
    $cat  = text($d, 'cat', 60);
    $loc  = text($d, 'loc', 120);
    $qty  = whole($d, 'qty', 0, 100000);
    $cond = (isset($d['cond']) && in_array($d['cond'], array('Good', 'Fair', 'Poor', 'Damaged'), true)) ? $d['cond'] : 'Good';
    $st   = (isset($d['st']) && in_array($d['st'], array('maintenance', 'unavailable'), true)) ? $d['st'] : '';

    if ($name === '' || $cat === '') {
        fail('Name and category are required.');
    }
    if ($qty === false) {
        fail('Quantity must be 0 or more.');
    }

    $pdo = db();
    if (!empty($d['id'])) {
        $id = num($d['id']);
        $up = $pdo->prepare(
            'UPDATE equipment SET name = ?, category = ?, qty = ?, item_condition = ?, location = ?, manual_status = ? WHERE id = ?'
        );
        $up->execute(array($name, $cat, $qty, $cond, $loc, $st, $id));
    } else {
        $ins = $pdo->prepare(
            'INSERT INTO equipment (name, category, qty, item_condition, location, manual_status) VALUES (?, ?, ?, ?, ?, ?)'
        );
        $ins->execute(array($name, $cat, $qty, $cond, $loc, $st));
    }
    json_out(array('ok' => true));
}

function action_eq_delete()
{
    require_role(array('admin', 'custodian'));
    $d  = body();
    $id = num(isset($d['id']) ? $d['id'] : '');
    $pdo = db();

    $busy = $pdo->prepare("SELECT COUNT(*) FROM requests WHERE eq_id = ? AND status IN ('pending','approved','released')");
    $busy->execute(array($id));
    if ((int) $busy->fetchColumn() > 0) {
        fail('This equipment has active requests or is on loan.');
    }
    $pdo->prepare('DELETE FROM equipment WHERE id = ?')->execute(array($id));
    json_out(array('ok' => true));
}

/* =====================================================================
 * Borrowing requests
 * ===================================================================== */

function action_rq_create()
{
    $u       = require_role(array('faculty', 'student'));
    $d       = body();
    $eqId    = num(isset($d['eq']) ? $d['eq'] : '');
    $qty     = whole($d, 'qty', 1, 100000);
    $from    = isset($d['from']) ? $d['from'] : '';
    $to      = isset($d['to']) ? $d['to'] : '';
    $purpose = text($d, 'purpose', 500);

    if ($qty === false) {
        fail('Enter a quantity of at least 1.');
    }
    if (!valid_date($from) || !valid_date($to)) {
        fail('Choose valid borrow and return dates.');
    }
    if ($from < today()) {
        fail('Borrow date cannot be in the past.');
    }
    if ($to < $from) {
        fail('Return date must be on or after the borrow date.');
    }
    if ($purpose === '') {
        fail('Please state the purpose.');
    }

    $pdo = db();
    $pdo->beginTransaction();
    // Lock the item so two people cannot grab the last unit at the same time.
    $st = $pdo->prepare('SELECT * FROM equipment WHERE id = ? FOR UPDATE');
    $st->execute(array($eqId));
    $item = $st->fetch();
    if (!$item) {
        fail('That equipment no longer exists.');
    }
    if ($item['manual_status'] !== '' || (int) $item['qty'] < 1) {
        fail('That equipment is not available for borrowing.');
    }
    $free = units_free($pdo, $eqId, $from, $to);
    if ($qty > $free) {
        fail('Only ' . max(0, $free) . ' unit(s) free for those dates.');
    }
    $ins = $pdo->prepare(
        "INSERT INTO requests (eq_id, user_id, qty, date_from, date_to, purpose, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')"
    );
    $ins->execute(array($eqId, $u['id'], $qty, $from, $to, $purpose));
    $pdo->commit();
    json_out(array('ok' => true));
}

/** Loads a request with a row lock inside a transaction. */
function lock_request($id)
{
    $pdo = db();
    $pdo->beginTransaction();
    $st = $pdo->prepare('SELECT * FROM requests WHERE id = ? FOR UPDATE');
    $st->execute(array($id));
    $r = $st->fetch();
    if (!$r) {
        fail('That request no longer exists.', 404);
    }
    return $r;
}

function action_rq_approve()
{
    require_role(array('admin', 'custodian'));
    $d  = body();
    $id = num(isset($d['id']) ? $d['id'] : '');
    $r  = lock_request($id);
    $pdo = db();

    if ($r['status'] !== 'pending') {
        fail('Only pending requests can be approved.');
    }
    if ($r['eq_id'] === null) {
        fail('That equipment was deleted.');
    }
    $pdo->prepare('SELECT id FROM equipment WHERE id = ? FOR UPDATE')->execute(array($r['eq_id']));
    $free = units_free($pdo, (int) $r['eq_id'], $r['date_from'], $r['date_to'], $id);
    if ((int) $r['qty'] > $free) {
        fail('Only ' . max(0, $free) . ' unit(s) free for ' . $r['date_from'] . ' to ' . $r['date_to'] . '.');
    }
    $pdo->prepare("UPDATE requests SET status = 'approved' WHERE id = ?")->execute(array($id));
    $pdo->commit();
    json_out(array('ok' => true));
}

function action_rq_reject()
{
    require_role(array('admin', 'custodian'));
    $d    = body();
    $id   = num(isset($d['id']) ? $d['id'] : '');
    $note = text($d, 'note', 500);
    if ($note === '') {
        fail('A reason is required.');
    }
    $r = lock_request($id);
    if (!in_array($r['status'], array('pending', 'approved'), true)) {
        fail('This request can no longer be rejected.');
    }
    $pdo = db();
    $pdo->prepare("UPDATE requests SET status = 'rejected', note = ? WHERE id = ?")->execute(array($note, $id));
    $pdo->commit();
    json_out(array('ok' => true));
}

function action_rq_release()
{
    require_role(array('admin', 'custodian'));
    $d  = body();
    $id = num(isset($d['id']) ? $d['id'] : '');
    $r  = lock_request($id);
    if ($r['status'] !== 'approved') {
        fail('Only approved requests can be released.');
    }
    $pdo = db();
    $pdo->prepare("UPDATE requests SET status = 'released', released_on = ? WHERE id = ?")->execute(array(today(), $id));
    $pdo->commit();
    json_out(array('ok' => true));
}

function action_rq_return()
{
    require_role(array('admin', 'custodian'));
    $d    = body();
    $id   = num(isset($d['id']) ? $d['id'] : '');
    $cond = isset($d['cond']) ? $d['cond'] : '';
    $note = text($d, 'note', 500);
    if (!in_array($cond, array('Good', 'Fair', 'Damaged', 'Lost'), true)) {
        fail('Choose the condition on return.');
    }
    $r = lock_request($id);
    if ($r['status'] !== 'released') {
        fail('Only released equipment can be returned.');
    }
    $pdo = db();
    $pdo->prepare(
        "UPDATE requests SET status = 'returned', returned_on = ?, return_condition = ?, note = ? WHERE id = ?"
    )->execute(array(today(), $cond, $note === '' ? null : $note, $id));

    if ($r['eq_id'] !== null) {
        if ($cond === 'Lost') {
            $pdo->prepare('UPDATE equipment SET qty = GREATEST(0, CAST(qty AS SIGNED) - ?) WHERE id = ?')
                ->execute(array((int) $r['qty'], $r['eq_id']));
        } elseif ($cond === 'Damaged') {
            $pdo->prepare("UPDATE equipment SET item_condition = 'Damaged', manual_status = 'maintenance' WHERE id = ?")
                ->execute(array($r['eq_id']));
        } else {
            $pdo->prepare('UPDATE equipment SET item_condition = ? WHERE id = ?')->execute(array($cond, $r['eq_id']));
        }
    }
    $pdo->commit();
    json_out(array('ok' => true));
}

function action_rq_cancel()
{
    $u  = require_user();
    $d  = body();
    $id = num(isset($d['id']) ? $d['id'] : '');
    $r  = lock_request($id);
    if ((int) $r['user_id'] !== (int) $u['id'] || $r['status'] !== 'pending') {
        fail('Only your own pending requests can be cancelled.', 403);
    }
    $pdo = db();
    $pdo->prepare("UPDATE requests SET status = 'cancelled' WHERE id = ?")->execute(array($id));
    $pdo->commit();
    json_out(array('ok' => true));
}
