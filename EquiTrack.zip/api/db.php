<?php
/*
 * Shared helpers for the EquiTrack API: configuration, database connection,
 * sessions, JSON output and input validation. Works on PHP 7.4 and newer.
 */

$CONFIG = require __DIR__ . '/config.php';
date_default_timezone_set(isset($CONFIG['timezone']) ? $CONFIG['timezone'] : 'Asia/Manila');

/* ---------- output ---------- */

function json_out($data, $code = 200)
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail($message, $code = 400)
{
    // Undo any half-finished transaction before answering.
    if (isset($GLOBALS['__pdo']) && $GLOBALS['__pdo']->inTransaction()) {
        $GLOBALS['__pdo']->rollBack();
    }
    json_out(array('error' => $message), $code);
}

/* ---------- database ---------- */

function db()
{
    if (isset($GLOBALS['__pdo'])) {
        return $GLOBALS['__pdo'];
    }
    global $CONFIG;
    if (empty($CONFIG['db_name']) || strpos($CONFIG['db_name'], 'XXXX') !== false) {
        fail('The database is not set up yet. Fill in api/config.php.', 500);
    }
    try {
        $dsn = 'mysql:host=' . $CONFIG['db_host'] . ';dbname=' . $CONFIG['db_name'] . ';charset=utf8mb4';
        $pdo = new PDO($dsn, $CONFIG['db_user'], $CONFIG['db_pass'], array(
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ));
    } catch (PDOException $e) {
        error_log('EquiTrack DB connection failed: ' . $e->getMessage());
        fail('Cannot connect to the database. Check the settings in api/config.php.', 500);
    }
    $GLOBALS['__pdo'] = $pdo;
    return $pdo;
}

function today()
{
    return date('Y-m-d');
}

/* ---------- sessions and permissions ---------- */

function start_session()
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('equitrack');
    session_set_cookie_params(array(
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ));
    session_start();
}

function current_user()
{
    start_session();
    if (empty($_SESSION['uid'])) {
        return null;
    }
    $st = db()->prepare('SELECT * FROM users WHERE id = ? AND active = 1');
    $st->execute(array((int) $_SESSION['uid']));
    $u = $st->fetch();
    if (!$u) {
        unset($_SESSION['uid']);
        return null;
    }
    return $u;
}

function require_user()
{
    $u = current_user();
    if (!$u) {
        fail('Please sign in.', 401);
    }
    return $u;
}

function require_role($roles)
{
    $u = require_user();
    if (!in_array($u['role'], $roles, true)) {
        fail('You do not have permission to do that.', 403);
    }
    return $u;
}

/* ---------- input ---------- */

function body()
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return array();
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        fail('Invalid request.', 400);
    }
    return $data;
}

function text($d, $key, $max = 255)
{
    $v = (isset($d[$key]) && is_scalar($d[$key])) ? trim((string) $d[$key]) : '';
    $len = function_exists('mb_strlen') ? mb_strlen($v, 'UTF-8') : strlen($v);
    if ($len > $max) {
        fail('One of the fields is too long (maximum ' . $max . ' characters).');
    }
    return $v;
}

function whole($d, $key, $min, $max)
{
    if (!isset($d[$key])) {
        return false;
    }
    $v = filter_var($d[$key], FILTER_VALIDATE_INT);
    if ($v === false || $v < $min || $v > $max) {
        return false;
    }
    return $v;
}

function valid_date($s)
{
    if (!is_string($s) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m)) {
        return false;
    }
    return checkdate((int) $m[2], (int) $m[3], (int) $m[1]);
}

/* ---------- ids shown to the browser (EQ-001, R-001, U1) ---------- */

function code($prefix, $id, $pad = 0)
{
    return $prefix . str_pad((string) $id, $pad, '0', STR_PAD_LEFT);
}

function num($v)
{
    return (int) preg_replace('/\D/', '', (string) $v);
}

function fmt_equipment($r)
{
    return array(
        'id'   => code('EQ-', $r['id'], 3),
        'name' => $r['name'],
        'cat'  => $r['category'],
        'qty'  => (int) $r['qty'],
        'cond' => $r['item_condition'],
        'loc'  => $r['location'],
        'st'   => $r['manual_status'],
    );
}

function fmt_user($r)
{
    return array(
        'id'     => code('U', $r['id']),
        'name'   => $r['name'],
        'email'  => $r['email'],
        'role'   => $r['role'],
        'dept'   => $r['dept'],
        'active' => (bool) $r['active'],
    );
}

function fmt_request($r, $anonymous = false)
{
    $row = array(
        'id'      => $anonymous ? '' : code('R-', $r['id'], 3),
        'eq'      => $r['eq_id'] === null ? '' : code('EQ-', $r['eq_id'], 3),
        'uid'     => $anonymous ? '' : code('U', $r['user_id']),
        'qty'     => (int) $r['qty'],
        'from'    => $r['date_from'],
        'to'      => $r['date_to'],
        'purpose' => $anonymous ? '' : $r['purpose'],
        'st'      => $r['status'],
    );
    if (!$anonymous) {
        $row['note'] = $r['note'];
        $row['out']  = $r['released_on'];
        $row['ret']  = $r['returned_on'];
        $row['cond'] = $r['return_condition'];
    }
    return $row;
}

/* ---------- availability ---------- */

/**
 * Units of an item that are still free for the period $from..$to.
 * Approved and released requests hold units. A released request that is
 * past its due date keeps holding them until it is returned.
 */
function units_free($pdo, $eqId, $from, $to, $excludeRequest = 0)
{
    $st = $pdo->prepare('SELECT qty FROM equipment WHERE id = ?');
    $st->execute(array($eqId));
    $item = $st->fetch();
    if (!$item) {
        return 0;
    }
    $q = $pdo->prepare(
        "SELECT qty, date_from, date_to, status FROM requests
         WHERE eq_id = ? AND status IN ('approved','released') AND id <> ?"
    );
    $q->execute(array($eqId, $excludeRequest));
    $used = 0;
    $today = today();
    foreach ($q->fetchAll() as $r) {
        $end = ($r['status'] === 'released' && $r['date_to'] < $today) ? '9999-12-31' : $r['date_to'];
        if ($r['date_from'] <= $to && $end >= $from) {
            $used += (int) $r['qty'];
        }
    }
    return (int) $item['qty'] - $used;
}
