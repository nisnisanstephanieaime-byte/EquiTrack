<?php
/*
 * SMCBI EquiTrack – database settings.
 *
 * On InfinityFree (free.nf) find these in the control panel under
 * "MySQL Databases". They are NOT "localhost":
 *   db_host  e.g. sql123.infinityfree.com   (shown as "MySQL Hostname")
 *   db_name  e.g. if0_12345678_equitrack    (create it first, includes your prefix)
 *   db_user  e.g. if0_12345678              (your account username)
 *   db_pass  your hosting account password (vPanel password)
 *
 * On your own computer (XAMPP/WAMP/Laragon) use host 'localhost', user 'root'
 * and an empty password.
 */
return [
    'db_host'  => 'sql304.infinityfree.com',
    'db_name'  => 'if0_43029559_equitrack',
    'db_user'  => 'if0_43029559',
    'db_pass'  => 'ESF7tOWwyja2I',
    'timezone' => 'Asia/Manila',
];
