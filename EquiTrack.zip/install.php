<?php
/*
 * One-time installer for SMCBI EquiTrack.
 * 1. Fill in api/config.php
 * 2. Open this page in the browser, create the first administrator
 * 3. DELETE this file from the server afterwards
 */

$lockFile = __DIR__ . '/api/installed.lock';
$config   = require __DIR__ . '/api/config.php';
date_default_timezone_set(isset($config['timezone']) ? $config['timezone'] : 'Asia/Manila');

function h($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function page($title, $html)
{
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width, initial-scale=1">'
       . '<title>' . h($title) . '</title><style>'
       . 'body{font:16px/1.5 system-ui,sans-serif;background:#eef2fa;color:#10203f;margin:0;padding:24px}'
       . '.card{max-width:460px;margin:6vh auto;background:#fff;border:1px solid #d2daec;border-top:6px solid #1e3f8e;border-radius:14px;padding:24px}'
       . 'h1{margin:0 0 6px;font-size:22px;color:#1e3f8e}label{display:block;margin:12px 0 4px;font-weight:600;font-size:14px}'
       . 'input[type=text],input[type=email],input[type=password]{width:100%;padding:9px 10px;border:1px solid #d2daec;border-radius:8px;font:inherit;box-sizing:border-box}'
       . 'button,a.btn{display:inline-block;margin-top:16px;background:#1e3f8e;color:#fff;border:0;border-radius:8px;padding:10px 18px;font:inherit;font-weight:600;cursor:pointer;text-decoration:none}'
       . '.err{background:#fdecea;border:1px solid #b3391f;color:#7d2412;padding:10px 12px;border-radius:8px;margin:12px 0}'
       . '.ok{background:#e8f5ee;border:1px solid #2a7d4f;color:#1d5a38;padding:10px 12px;border-radius:8px;margin:12px 0}'
       . '.mut{color:#56637f;font-size:14px}code{background:#eef2fa;padding:1px 5px;border-radius:4px}'
       . '</style></head><body><div class="card">' . $html . '</div></body></html>';
    exit;
}

/* ---- connect ---- */
try {
    $pdo = new PDO(
        'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
        $config['db_user'],
        $config['db_pass'],
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC)
    );
} catch (PDOException $e) {
    page('EquiTrack setup', '<h1>Cannot connect to the database</h1>'
        . '<div class="err">' . h($e->getMessage()) . '</div>'
        . '<p class="mut">Open <code>api/config.php</code> and check the host, database name, username and password. '
        . 'On InfinityFree the host looks like <code>sql123.infinityfree.com</code>, not <code>localhost</code>.</p>');
}

/* ---- already installed? ---- */
$alreadyHasUsers = false;
try {
    $alreadyHasUsers = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() > 0;
} catch (PDOException $e) {
    // The tables do not exist yet, which is expected on a fresh install.
}
if (file_exists($lockFile) || $alreadyHasUsers) {
    page('EquiTrack setup', '<h1>Already installed</h1>'
        . '<div class="ok">EquiTrack is set up. For safety, delete <code>install.php</code> from your server.</div>'
        . '<a class="btn" href="index.html">Open EquiTrack</a>');
}

/* ---- run the installation ---- */
$error = '';
$name = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim(isset($_POST['name']) ? $_POST['name'] : '');
    $email = strtolower(trim(isset($_POST['email']) ? $_POST['email'] : ''));
    $pass  = isset($_POST['password']) ? $_POST['password'] : '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter the administrator name and a valid email.';
    } elseif (strlen($pass) < 8) {
        $error = 'Use a password of at least 8 characters.';
    } else {
        try {
            $sql = file_get_contents(__DIR__ . '/database.sql');
            $sql = preg_replace('/^\s*--.*$/m', '', $sql);
            foreach (explode(';', $sql) as $statement) {
                if (trim($statement) !== '') {
                    $pdo->exec($statement);
                }
            }

            $pdo->prepare('INSERT INTO users (name, email, pw_hash, role, dept, active) VALUES (?, ?, ?, ?, ?, 1)')
                ->execute(array($name, $email, password_hash($pass, PASSWORD_DEFAULT), 'admin', 'IT Office'));

            if (!empty($_POST['sample']) && (int) $pdo->query('SELECT COUNT(*) FROM equipment')->fetchColumn() === 0) {
                $items = array(
                    array('Projector (Epson)', 'Audio-Visual', 4, 'Good', 'AV Room'),
                    array('Laptop (Lenovo)', 'Computers', 10, 'Good', 'IT Lab'),
                    array('Wireless Microphone', 'Audio-Visual', 3, 'Good', 'AV Room'),
                    array('Extension Cord 10m', 'Electrical', 8, 'Good', 'Supply Room'),
                    array('Digital Camera', 'Audio-Visual', 2, 'Fair', 'Media Office'),
                    array('Multimeter', 'Laboratory', 6, 'Good', 'Science Lab'),
                    array('Portable Speaker', 'Audio-Visual', 3, 'Good', 'AV Room'),
                    array('Microscope', 'Laboratory', 5, 'Good', 'Science Lab'),
                    array('HDMI Cable', 'Computers', 12, 'Good', 'IT Lab'),
                    array('Tripod', 'Audio-Visual', 2, 'Fair', 'Media Office'),
                );
                $ins = $pdo->prepare('INSERT INTO equipment (name, category, qty, item_condition, location) VALUES (?, ?, ?, ?, ?)');
                foreach ($items as $it) {
                    $ins->execute($it);
                }
            }

            $locked = @file_put_contents($lockFile, 'installed ' . date('c'));
            $msg = '<div class="ok">Done. The database tables and your administrator account are ready.</div>';
            if ($locked === false) {
                $msg .= '<div class="err">Could not write <code>api/installed.lock</code>. Delete <code>install.php</code> from the server now.</div>';
            } else {
                $msg .= '<p class="mut">Now delete <code>install.php</code> from your server.</p>';
            }
            page('EquiTrack setup', '<h1>Installed</h1>' . $msg . '<a class="btn" href="index.html">Open EquiTrack</a>');
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

/* ---- form ---- */
page('EquiTrack setup',
    '<h1>SMCBI EquiTrack setup</h1>'
    . '<p class="mut">Creates the database tables and your first administrator account.</p>'
    . ($error !== '' ? '<div class="err">' . h($error) . '</div>' : '')
    . '<form method="post">'
    . '<label for="n">Administrator name</label><input id="n" type="text" name="name" value="' . h($name) . '" required>'
    . '<label for="e">Email</label><input id="e" type="email" name="email" value="' . h($email) . '" required>'
    . '<label for="p">Password (8+ characters)</label><input id="p" type="password" name="password" required>'
    . '<label><input type="checkbox" name="sample" value="1" checked> Add the sample equipment list</label>'
    . '<button type="submit">Install</button></form>');
