<?php
$config = require __DIR__ . '/api/config.php';
$pdo = new PDO(
    'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
    $config['db_user'],
    $config['db_pass']
);

$email = 'admin@example.com';
$password = 'password123';
$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare('UPDATE users SET pw_hash = ?, active = 1 WHERE email = ?');
$stmt->execute([$hash, $email]);

if ($stmt->rowCount() > 0) {
    echo 'Password successfully updated!';
} else {
    // If user doesn't exist yet, insert it
    $stmt = $pdo->prepare('INSERT INTO users (name, email, pw_hash, role, dept, active) VALUES (?, ?, ?, ?, ?, 1)');
    $stmt->execute(['Admin', $email, $hash, 'admin', 'IT Office']);
    echo 'Admin account successfully created!';
}